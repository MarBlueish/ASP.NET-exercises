﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Ati7FPFutebol
{
    public partial class Eliminar : Page
    {
        protected void b_eliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_id_eliminar.Text))
            {
                return;
            }

            string connetionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Ati7FPFutebol\App_Data\dbFPF.mdf;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connetionString))
            {
                con.Open();

                string sql = "DELETE FROM tab_jogador WHERE N_federacao = @N_federacao";

                using (SqlCommand command = new SqlCommand(sql, con))
                {
                    command.Parameters.AddWithValue("@N_federacao", int.Parse(txt_id_eliminar.Text));

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        ltEliminarOutput.Text = "Jogador eliminado";
                    }
                    else
                    {
                        ltEliminarOutput.Text = "Erro, jogador não existe";
                    }
                }
            }

            txt_id_eliminar.Text = "";
        }


    }
}