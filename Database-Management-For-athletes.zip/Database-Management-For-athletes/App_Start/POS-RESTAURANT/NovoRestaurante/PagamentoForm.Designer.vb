﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PagamentoForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(PagamentoForm))
        Panel2 = New Panel()
        GroupBoxPesquisa = New GroupBox()
        lblPesquisar = New Label()
        TextBox1 = New TextBox()
        BtnFechar = New Button()
        Panel1 = New Panel()
        BtnLogout = New Button()
        Lbl_time = New Label()
        BtnRecuperarSenha = New Button()
        BtnUsuarios = New Button()
        Lbl_Data = New Label()
        BtnAbout = New Button()
        BtnMesas = New Button()
        Lbl_User = New Label()
        BtnProdutoBruto = New Button()
        Label5 = New Label()
        BtnFornecedor = New Button()
        BtnPratos = New Button()
        BtnStock = New Button()
        Button2 = New Button()
        BtnPedidosDelivery = New Button()
        Panel6 = New Panel()
        DataGridView2 = New DataGridView()
        DataGridViewTextBoxColumn1 = New DataGridViewTextBoxColumn()
        DataGridViewTextBoxColumn2 = New DataGridViewTextBoxColumn()
        DataGridViewTextBoxColumn3 = New DataGridViewTextBoxColumn()
        Panel4 = New Panel()
        Button7 = New Button()
        BtnMesa1 = New Button()
        Button6 = New Button()
        BtnMesa11 = New Button()
        Button8 = New Button()
        BtnMesa7 = New Button()
        Button5 = New Button()
        BtnMesa12 = New Button()
        Button3 = New Button()
        BtnMesa6 = New Button()
        BtnMesa5 = New Button()
        BtnMesa16 = New Button()
        BtnMesa15 = New Button()
        BtnMesa2 = New Button()
        BtnMesa10 = New Button()
        BtnMesa20 = New Button()
        BtnMesa19 = New Button()
        BtnMesa17 = New Button()
        BtnMesa4 = New Button()
        BtnMesa13 = New Button()
        BtnMesa3 = New Button()
        BtnMesa9 = New Button()
        BtnMesa18 = New Button()
        BtnMesa14 = New Button()
        BtnMesa8 = New Button()
        Panel3 = New Panel()
        Button13 = New Button()
        Button12 = New Button()
        Button11 = New Button()
        Button10 = New Button()
        Button9 = New Button()
        BtnC = New Button()
        Btn_dot = New Button()
        Btn0 = New Button()
        Btn3 = New Button()
        Btn2 = New Button()
        Btn1 = New Button()
        Btn6 = New Button()
        Btn5 = New Button()
        Btn4 = New Button()
        Btn9 = New Button()
        Btn8 = New Button()
        Btn7 = New Button()
        Panel9 = New Panel()
        BtnRemover = New Button()
        BtnPagamento = New Button()
        BtnLimpar = New Button()
        Btn_Imprimir = New Button()
        Panel7 = New Panel()
        TextBoxTotal = New TextBox()
        cboPag = New ComboBox()
        TextBoxIva = New TextBox()
        TextBoxSubTotal = New TextBox()
        lblTotal = New Label()
        TextBoxTroco = New TextBox()
        lblIva = New Label()
        lblSubTotal = New Label()
        lblTroco = New Label()
        lblFormaPag = New Label()
        lblCusto = New Label()
        DataGridView1 = New DataGridView()
        Column1 = New DataGridViewTextBoxColumn()
        Column2 = New DataGridViewTextBoxColumn()
        Column3 = New DataGridViewTextBoxColumn()
        TextBoxCusto = New TextBox()
        Panel2.SuspendLayout()
        GroupBoxPesquisa.SuspendLayout()
        Panel1.SuspendLayout()
        Panel6.SuspendLayout()
        CType(DataGridView2, ComponentModel.ISupportInitialize).BeginInit()
        Panel4.SuspendLayout()
        Panel3.SuspendLayout()
        Panel9.SuspendLayout()
        Panel7.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.Maroon
        Panel2.Controls.Add(GroupBoxPesquisa)
        Panel2.Controls.Add(BtnFechar)
        Panel2.Dock = DockStyle.Top
        Panel2.Location = New Point(232, 0)
        Panel2.Margin = New Padding(3, 2, 3, 2)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(1080, 56)
        Panel2.TabIndex = 32
        ' 
        ' GroupBoxPesquisa
        ' 
        GroupBoxPesquisa.Controls.Add(lblPesquisar)
        GroupBoxPesquisa.Controls.Add(TextBox1)
        GroupBoxPesquisa.FlatStyle = FlatStyle.Flat
        GroupBoxPesquisa.Location = New Point(2, 2)
        GroupBoxPesquisa.Margin = New Padding(3, 2, 3, 2)
        GroupBoxPesquisa.Name = "GroupBoxPesquisa"
        GroupBoxPesquisa.Padding = New Padding(3, 2, 3, 2)
        GroupBoxPesquisa.Size = New Size(970, 51)
        GroupBoxPesquisa.TabIndex = 32
        GroupBoxPesquisa.TabStop = False
        ' 
        ' lblPesquisar
        ' 
        lblPesquisar.AutoSize = True
        lblPesquisar.Font = New Font("Century Gothic", 12F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        lblPesquisar.ForeColor = Color.Snow
        lblPesquisar.Location = New Point(642, 22)
        lblPesquisar.Name = "lblPesquisar"
        lblPesquisar.Size = New Size(84, 21)
        lblPesquisar.TabIndex = 1
        lblPesquisar.Text = "Pesquisar"
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(744, 19)
        TextBox1.Margin = New Padding(3, 2, 3, 2)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(176, 23)
        TextBox1.TabIndex = 0
        ' 
        ' BtnFechar
        ' 
        BtnFechar.BackColor = Color.Transparent
        BtnFechar.BackgroundImage = CType(resources.GetObject("BtnFechar.BackgroundImage"), Image)
        BtnFechar.BackgroundImageLayout = ImageLayout.Stretch
        BtnFechar.FlatAppearance.BorderSize = 0
        BtnFechar.FlatStyle = FlatStyle.Flat
        BtnFechar.Location = New Point(1040, 0)
        BtnFechar.Margin = New Padding(3, 2, 3, 2)
        BtnFechar.Name = "BtnFechar"
        BtnFechar.Size = New Size(38, 28)
        BtnFechar.TabIndex = 31
        BtnFechar.UseVisualStyleBackColor = False
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Maroon
        Panel1.Controls.Add(BtnLogout)
        Panel1.Controls.Add(Lbl_time)
        Panel1.Controls.Add(BtnRecuperarSenha)
        Panel1.Controls.Add(BtnUsuarios)
        Panel1.Controls.Add(Lbl_Data)
        Panel1.Controls.Add(BtnAbout)
        Panel1.Controls.Add(BtnMesas)
        Panel1.Controls.Add(Lbl_User)
        Panel1.Controls.Add(BtnProdutoBruto)
        Panel1.Controls.Add(Label5)
        Panel1.Controls.Add(BtnFornecedor)
        Panel1.Controls.Add(BtnPratos)
        Panel1.Controls.Add(BtnStock)
        Panel1.Controls.Add(Button2)
        Panel1.Controls.Add(BtnPedidosDelivery)
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 0)
        Panel1.Margin = New Padding(3, 2, 3, 2)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(232, 600)
        Panel1.TabIndex = 31
        ' 
        ' BtnLogout
        ' 
        BtnLogout.BackColor = Color.Maroon
        BtnLogout.Cursor = Cursors.Hand
        BtnLogout.FlatAppearance.BorderSize = 0
        BtnLogout.FlatStyle = FlatStyle.Flat
        BtnLogout.Font = New Font("Century Gothic", 22.2F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        BtnLogout.ForeColor = Color.Black
        BtnLogout.Image = CType(resources.GetObject("BtnLogout.Image"), Image)
        BtnLogout.ImageAlign = ContentAlignment.MiddleLeft
        BtnLogout.Location = New Point(17, 438)
        BtnLogout.Margin = New Padding(3, 2, 3, 2)
        BtnLogout.Name = "BtnLogout"
        BtnLogout.Size = New Size(197, 44)
        BtnLogout.TabIndex = 128
        BtnLogout.Text = "     Logout"
        BtnLogout.UseVisualStyleBackColor = False
        ' 
        ' Lbl_time
        ' 
        Lbl_time.AutoSize = True
        Lbl_time.Font = New Font("Segoe UI", 10.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Lbl_time.ForeColor = Color.White
        Lbl_time.Location = New Point(107, 578)
        Lbl_time.Name = "Lbl_time"
        Lbl_time.Size = New Size(44, 20)
        Lbl_time.TabIndex = 37
        Lbl_time.Text = "Data"
        ' 
        ' BtnRecuperarSenha
        ' 
        BtnRecuperarSenha.BackColor = Color.Maroon
        BtnRecuperarSenha.FlatStyle = FlatStyle.Flat
        BtnRecuperarSenha.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        BtnRecuperarSenha.ForeColor = Color.Snow
        BtnRecuperarSenha.Location = New Point(17, 290)
        BtnRecuperarSenha.Margin = New Padding(3, 2, 3, 2)
        BtnRecuperarSenha.Name = "BtnRecuperarSenha"
        BtnRecuperarSenha.Size = New Size(197, 28)
        BtnRecuperarSenha.TabIndex = 123
        BtnRecuperarSenha.Text = "Recuperar Senha"
        BtnRecuperarSenha.UseVisualStyleBackColor = False
        ' 
        ' BtnUsuarios
        ' 
        BtnUsuarios.BackColor = Color.Maroon
        BtnUsuarios.FlatStyle = FlatStyle.Flat
        BtnUsuarios.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        BtnUsuarios.ForeColor = Color.Snow
        BtnUsuarios.Location = New Point(17, 365)
        BtnUsuarios.Margin = New Padding(3, 2, 3, 2)
        BtnUsuarios.Name = "BtnUsuarios"
        BtnUsuarios.Size = New Size(197, 28)
        BtnUsuarios.TabIndex = 126
        BtnUsuarios.Text = "Usuários"
        BtnUsuarios.UseVisualStyleBackColor = False
        ' 
        ' Lbl_Data
        ' 
        Lbl_Data.AutoSize = True
        Lbl_Data.Font = New Font("Segoe UI", 10.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Lbl_Data.ForeColor = Color.White
        Lbl_Data.Location = New Point(51, 578)
        Lbl_Data.Name = "Lbl_Data"
        Lbl_Data.Size = New Size(54, 20)
        Lbl_Data.TabIndex = 36
        Lbl_Data.Text = "Data:-"
        ' 
        ' BtnAbout
        ' 
        BtnAbout.BackColor = Color.Maroon
        BtnAbout.FlatStyle = FlatStyle.Flat
        BtnAbout.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        BtnAbout.ForeColor = Color.Snow
        BtnAbout.Location = New Point(17, 48)
        BtnAbout.Margin = New Padding(3, 2, 3, 2)
        BtnAbout.Name = "BtnAbout"
        BtnAbout.Size = New Size(197, 28)
        BtnAbout.TabIndex = 117
        BtnAbout.Text = "About"
        BtnAbout.UseVisualStyleBackColor = False
        ' 
        ' BtnMesas
        ' 
        BtnMesas.BackColor = Color.Maroon
        BtnMesas.FlatStyle = FlatStyle.Flat
        BtnMesas.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        BtnMesas.ForeColor = Color.Snow
        BtnMesas.Location = New Point(17, 152)
        BtnMesas.Margin = New Padding(3, 2, 3, 2)
        BtnMesas.Name = "BtnMesas"
        BtnMesas.Size = New Size(197, 28)
        BtnMesas.TabIndex = 118
        BtnMesas.Text = "Mesas"
        BtnMesas.UseVisualStyleBackColor = False
        ' 
        ' Lbl_User
        ' 
        Lbl_User.AutoSize = True
        Lbl_User.Font = New Font("Segoe UI Semibold", 10.2F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Lbl_User.ForeColor = Color.Snow
        Lbl_User.Location = New Point(166, 544)
        Lbl_User.Name = "Lbl_User"
        Lbl_User.Size = New Size(37, 19)
        Lbl_User.TabIndex = 40
        Lbl_User.Text = "User"
        ' 
        ' BtnProdutoBruto
        ' 
        BtnProdutoBruto.BackColor = Color.Maroon
        BtnProdutoBruto.FlatStyle = FlatStyle.Flat
        BtnProdutoBruto.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        BtnProdutoBruto.ForeColor = Color.Snow
        BtnProdutoBruto.Location = New Point(17, 255)
        BtnProdutoBruto.Margin = New Padding(3, 2, 3, 2)
        BtnProdutoBruto.Name = "BtnProdutoBruto"
        BtnProdutoBruto.Size = New Size(197, 28)
        BtnProdutoBruto.TabIndex = 124
        BtnProdutoBruto.Text = "Produto Bruto"
        BtnProdutoBruto.UseVisualStyleBackColor = False
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI Semibold", 10.2F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label5.ForeColor = Color.Snow
        Label5.Location = New Point(34, 544)
        Label5.Name = "Label5"
        Label5.Size = New Size(129, 19)
        Label5.TabIndex = 39
        Label5.Text = "Seja Bem Vindo(a),"
        ' 
        ' BtnFornecedor
        ' 
        BtnFornecedor.BackColor = Color.Maroon
        BtnFornecedor.FlatStyle = FlatStyle.Flat
        BtnFornecedor.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        BtnFornecedor.ForeColor = Color.Snow
        BtnFornecedor.Location = New Point(17, 82)
        BtnFornecedor.Margin = New Padding(3, 2, 3, 2)
        BtnFornecedor.Name = "BtnFornecedor"
        BtnFornecedor.Size = New Size(197, 28)
        BtnFornecedor.TabIndex = 120
        BtnFornecedor.Text = "Fornecedor"
        BtnFornecedor.UseVisualStyleBackColor = False
        ' 
        ' BtnPratos
        ' 
        BtnPratos.BackColor = Color.Maroon
        BtnPratos.FlatStyle = FlatStyle.Flat
        BtnPratos.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        BtnPratos.ForeColor = Color.Snow
        BtnPratos.Location = New Point(17, 117)
        BtnPratos.Margin = New Padding(3, 2, 3, 2)
        BtnPratos.Name = "BtnPratos"
        BtnPratos.Size = New Size(197, 28)
        BtnPratos.TabIndex = 125
        BtnPratos.Text = "Home"
        BtnPratos.UseVisualStyleBackColor = False
        ' 
        ' BtnStock
        ' 
        BtnStock.BackColor = Color.Maroon
        BtnStock.FlatStyle = FlatStyle.Flat
        BtnStock.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        BtnStock.ForeColor = Color.Snow
        BtnStock.Location = New Point(17, 330)
        BtnStock.Margin = New Padding(3, 2, 3, 2)
        BtnStock.Name = "BtnStock"
        BtnStock.Size = New Size(198, 28)
        BtnStock.TabIndex = 121
        BtnStock.Text = "Stock"
        BtnStock.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.Maroon
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Button2.ForeColor = Color.Snow
        Button2.Location = New Point(17, 186)
        Button2.Margin = New Padding(3, 2, 3, 2)
        Button2.Name = "Button2"
        Button2.Size = New Size(197, 28)
        Button2.TabIndex = 127
        Button2.Text = "Pagamento"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' BtnPedidosDelivery
        ' 
        BtnPedidosDelivery.BackColor = Color.Maroon
        BtnPedidosDelivery.FlatStyle = FlatStyle.Flat
        BtnPedidosDelivery.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        BtnPedidosDelivery.ForeColor = Color.Snow
        BtnPedidosDelivery.Location = New Point(17, 220)
        BtnPedidosDelivery.Margin = New Padding(3, 2, 3, 2)
        BtnPedidosDelivery.Name = "BtnPedidosDelivery"
        BtnPedidosDelivery.Size = New Size(197, 28)
        BtnPedidosDelivery.TabIndex = 119
        BtnPedidosDelivery.Text = "Pedidos Delivery"
        BtnPedidosDelivery.UseVisualStyleBackColor = False
        ' 
        ' Panel6
        ' 
        Panel6.BackColor = Color.Brown
        Panel6.BorderStyle = BorderStyle.Fixed3D
        Panel6.Controls.Add(DataGridView2)
        Panel6.Controls.Add(Panel4)
        Panel6.Controls.Add(Panel3)
        Panel6.Location = New Point(241, 321)
        Panel6.Margin = New Padding(3, 2, 3, 2)
        Panel6.Name = "Panel6"
        Panel6.Size = New Size(1070, 276)
        Panel6.TabIndex = 54
        ' 
        ' DataGridView2
        ' 
        DataGridView2.BackgroundColor = Color.Snow
        DataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView2.Columns.AddRange(New DataGridViewColumn() {DataGridViewTextBoxColumn1, DataGridViewTextBoxColumn2, DataGridViewTextBoxColumn3})
        DataGridView2.Location = New Point(354, 7)
        DataGridView2.Margin = New Padding(3, 2, 3, 2)
        DataGridView2.Name = "DataGridView2"
        DataGridView2.RowHeadersWidth = 51
        DataGridView2.RowTemplate.Height = 29
        DataGridView2.Size = New Size(428, 260)
        DataGridView2.TabIndex = 50
        ' 
        ' DataGridViewTextBoxColumn1
        ' 
        DataGridViewTextBoxColumn1.HeaderText = "Item"
        DataGridViewTextBoxColumn1.MinimumWidth = 6
        DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        DataGridViewTextBoxColumn1.Width = 125
        ' 
        ' DataGridViewTextBoxColumn2
        ' 
        DataGridViewTextBoxColumn2.HeaderText = "Qtd"
        DataGridViewTextBoxColumn2.MinimumWidth = 6
        DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        DataGridViewTextBoxColumn2.Width = 125
        ' 
        ' DataGridViewTextBoxColumn3
        ' 
        DataGridViewTextBoxColumn3.HeaderText = "Valor"
        DataGridViewTextBoxColumn3.MinimumWidth = 6
        DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        DataGridViewTextBoxColumn3.Width = 125
        ' 
        ' Panel4
        ' 
        Panel4.AutoScroll = True
        Panel4.BackColor = SystemColors.Control
        Panel4.BorderStyle = BorderStyle.Fixed3D
        Panel4.Controls.Add(Button7)
        Panel4.Controls.Add(BtnMesa1)
        Panel4.Controls.Add(Button6)
        Panel4.Controls.Add(BtnMesa11)
        Panel4.Controls.Add(Button8)
        Panel4.Controls.Add(BtnMesa7)
        Panel4.Controls.Add(Button5)
        Panel4.Controls.Add(BtnMesa12)
        Panel4.Controls.Add(Button3)
        Panel4.Controls.Add(BtnMesa6)
        Panel4.Controls.Add(BtnMesa5)
        Panel4.Controls.Add(BtnMesa16)
        Panel4.Controls.Add(BtnMesa15)
        Panel4.Controls.Add(BtnMesa2)
        Panel4.Controls.Add(BtnMesa10)
        Panel4.Controls.Add(BtnMesa20)
        Panel4.Controls.Add(BtnMesa19)
        Panel4.Controls.Add(BtnMesa17)
        Panel4.Controls.Add(BtnMesa4)
        Panel4.Controls.Add(BtnMesa13)
        Panel4.Controls.Add(BtnMesa3)
        Panel4.Controls.Add(BtnMesa9)
        Panel4.Controls.Add(BtnMesa18)
        Panel4.Controls.Add(BtnMesa14)
        Panel4.Controls.Add(BtnMesa8)
        Panel4.Location = New Point(3, 7)
        Panel4.Margin = New Padding(3, 2, 3, 2)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(282, 256)
        Panel4.TabIndex = 33
        ' 
        ' Button7
        ' 
        Button7.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Button7.Location = New Point(186, 218)
        Button7.Margin = New Padding(3, 2, 3, 2)
        Button7.Name = "Button7"
        Button7.Size = New Size(87, 26)
        Button7.TabIndex = 125
        Button7.Text = "Mesa24"
        Button7.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa1
        ' 
        BtnMesa1.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa1.Location = New Point(3, 2)
        BtnMesa1.Margin = New Padding(3, 2, 3, 2)
        BtnMesa1.Name = "BtnMesa1"
        BtnMesa1.Size = New Size(87, 26)
        BtnMesa1.TabIndex = 102
        BtnMesa1.Text = "Mesa1"
        BtnMesa1.UseVisualStyleBackColor = True
        ' 
        ' Button6
        ' 
        Button6.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Button6.Location = New Point(94, 218)
        Button6.Margin = New Padding(3, 2, 3, 2)
        Button6.Name = "Button6"
        Button6.Size = New Size(87, 26)
        Button6.TabIndex = 124
        Button6.Text = "Mesa23"
        Button6.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa11
        ' 
        BtnMesa11.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa11.Location = New Point(94, 94)
        BtnMesa11.Margin = New Padding(3, 2, 3, 2)
        BtnMesa11.Name = "BtnMesa11"
        BtnMesa11.Size = New Size(87, 26)
        BtnMesa11.TabIndex = 106
        BtnMesa11.Text = "Mesa11"
        BtnMesa11.UseVisualStyleBackColor = True
        ' 
        ' Button8
        ' 
        Button8.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Button8.Location = New Point(246, 578)
        Button8.Margin = New Padding(3, 2, 3, 2)
        Button8.Name = "Button8"
        Button8.Size = New Size(87, 26)
        Button8.TabIndex = 126
        Button8.Text = "Mesa25"
        Button8.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa7
        ' 
        BtnMesa7.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa7.Location = New Point(3, 64)
        BtnMesa7.Margin = New Padding(3, 2, 3, 2)
        BtnMesa7.Name = "BtnMesa7"
        BtnMesa7.Size = New Size(87, 26)
        BtnMesa7.TabIndex = 105
        BtnMesa7.Text = "Mesa7"
        BtnMesa7.UseVisualStyleBackColor = True
        ' 
        ' Button5
        ' 
        Button5.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Button5.Location = New Point(3, 218)
        Button5.Margin = New Padding(3, 2, 3, 2)
        Button5.Name = "Button5"
        Button5.Size = New Size(87, 26)
        Button5.TabIndex = 123
        Button5.Text = "Mesa22"
        Button5.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa12
        ' 
        BtnMesa12.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa12.Location = New Point(186, 94)
        BtnMesa12.Margin = New Padding(3, 2, 3, 2)
        BtnMesa12.Name = "BtnMesa12"
        BtnMesa12.Size = New Size(87, 26)
        BtnMesa12.TabIndex = 107
        BtnMesa12.Text = "Mesa12"
        BtnMesa12.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Button3.Location = New Point(186, 187)
        Button3.Margin = New Padding(3, 2, 3, 2)
        Button3.Name = "Button3"
        Button3.Size = New Size(87, 26)
        Button3.TabIndex = 122
        Button3.Text = "Mesa21"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa6
        ' 
        BtnMesa6.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa6.Location = New Point(186, 33)
        BtnMesa6.Margin = New Padding(3, 2, 3, 2)
        BtnMesa6.Name = "BtnMesa6"
        BtnMesa6.Size = New Size(87, 26)
        BtnMesa6.TabIndex = 104
        BtnMesa6.Text = "Mesa6"
        BtnMesa6.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa5
        ' 
        BtnMesa5.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa5.Location = New Point(94, 33)
        BtnMesa5.Margin = New Padding(3, 2, 3, 2)
        BtnMesa5.Name = "BtnMesa5"
        BtnMesa5.Size = New Size(87, 26)
        BtnMesa5.TabIndex = 119
        BtnMesa5.Text = "Mesa5"
        BtnMesa5.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa16
        ' 
        BtnMesa16.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa16.Location = New Point(3, 156)
        BtnMesa16.Margin = New Padding(3, 2, 3, 2)
        BtnMesa16.Name = "BtnMesa16"
        BtnMesa16.Size = New Size(87, 26)
        BtnMesa16.TabIndex = 108
        BtnMesa16.Text = "Mesa16"
        BtnMesa16.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa15
        ' 
        BtnMesa15.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa15.Location = New Point(186, 125)
        BtnMesa15.Margin = New Padding(3, 2, 3, 2)
        BtnMesa15.Name = "BtnMesa15"
        BtnMesa15.Size = New Size(87, 26)
        BtnMesa15.TabIndex = 121
        BtnMesa15.Text = "Mesa15"
        BtnMesa15.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa2
        ' 
        BtnMesa2.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa2.Location = New Point(94, 2)
        BtnMesa2.Margin = New Padding(3, 2, 3, 2)
        BtnMesa2.Name = "BtnMesa2"
        BtnMesa2.Size = New Size(87, 26)
        BtnMesa2.TabIndex = 103
        BtnMesa2.Text = "Mesa2"
        BtnMesa2.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa10
        ' 
        BtnMesa10.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa10.Location = New Point(3, 94)
        BtnMesa10.Margin = New Padding(3, 2, 3, 2)
        BtnMesa10.Name = "BtnMesa10"
        BtnMesa10.Size = New Size(87, 26)
        BtnMesa10.TabIndex = 120
        BtnMesa10.Text = "Mesa10"
        BtnMesa10.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa20
        ' 
        BtnMesa20.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa20.Location = New Point(94, 187)
        BtnMesa20.Margin = New Padding(3, 2, 3, 2)
        BtnMesa20.Name = "BtnMesa20"
        BtnMesa20.Size = New Size(87, 26)
        BtnMesa20.TabIndex = 110
        BtnMesa20.Text = "Mesa20"
        BtnMesa20.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa19
        ' 
        BtnMesa19.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa19.Location = New Point(3, 187)
        BtnMesa19.Margin = New Padding(3, 2, 3, 2)
        BtnMesa19.Name = "BtnMesa19"
        BtnMesa19.Size = New Size(87, 26)
        BtnMesa19.TabIndex = 118
        BtnMesa19.Text = "Mesa19"
        BtnMesa19.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa17
        ' 
        BtnMesa17.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa17.Location = New Point(94, 156)
        BtnMesa17.Margin = New Padding(3, 2, 3, 2)
        BtnMesa17.Name = "BtnMesa17"
        BtnMesa17.Size = New Size(87, 26)
        BtnMesa17.TabIndex = 109
        BtnMesa17.Text = "Mesa17"
        BtnMesa17.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa4
        ' 
        BtnMesa4.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa4.Location = New Point(3, 33)
        BtnMesa4.Margin = New Padding(3, 2, 3, 2)
        BtnMesa4.Name = "BtnMesa4"
        BtnMesa4.Size = New Size(87, 26)
        BtnMesa4.TabIndex = 112
        BtnMesa4.Text = "Mesa4"
        BtnMesa4.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa13
        ' 
        BtnMesa13.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa13.Location = New Point(3, 125)
        BtnMesa13.Margin = New Padding(3, 2, 3, 2)
        BtnMesa13.Name = "BtnMesa13"
        BtnMesa13.Size = New Size(87, 26)
        BtnMesa13.TabIndex = 115
        BtnMesa13.Text = "Mesa13"
        BtnMesa13.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa3
        ' 
        BtnMesa3.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa3.Location = New Point(186, 2)
        BtnMesa3.Margin = New Padding(3, 2, 3, 2)
        BtnMesa3.Name = "BtnMesa3"
        BtnMesa3.Size = New Size(87, 26)
        BtnMesa3.TabIndex = 111
        BtnMesa3.Text = "Mesa3"
        BtnMesa3.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa9
        ' 
        BtnMesa9.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa9.Location = New Point(186, 64)
        BtnMesa9.Margin = New Padding(3, 2, 3, 2)
        BtnMesa9.Name = "BtnMesa9"
        BtnMesa9.Size = New Size(87, 26)
        BtnMesa9.TabIndex = 114
        BtnMesa9.Text = "Mesa9"
        BtnMesa9.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa18
        ' 
        BtnMesa18.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa18.Location = New Point(186, 156)
        BtnMesa18.Margin = New Padding(3, 2, 3, 2)
        BtnMesa18.Name = "BtnMesa18"
        BtnMesa18.Size = New Size(87, 26)
        BtnMesa18.TabIndex = 117
        BtnMesa18.Text = "Mesa18"
        BtnMesa18.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa14
        ' 
        BtnMesa14.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa14.Location = New Point(94, 125)
        BtnMesa14.Margin = New Padding(3, 2, 3, 2)
        BtnMesa14.Name = "BtnMesa14"
        BtnMesa14.Size = New Size(87, 26)
        BtnMesa14.TabIndex = 116
        BtnMesa14.Text = "Mesa14"
        BtnMesa14.UseVisualStyleBackColor = True
        ' 
        ' BtnMesa8
        ' 
        BtnMesa8.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        BtnMesa8.Location = New Point(94, 64)
        BtnMesa8.Margin = New Padding(3, 2, 3, 2)
        BtnMesa8.Name = "BtnMesa8"
        BtnMesa8.Size = New Size(87, 26)
        BtnMesa8.TabIndex = 113
        BtnMesa8.Text = "Mesa8"
        BtnMesa8.UseVisualStyleBackColor = True
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = SystemColors.Control
        Panel3.BorderStyle = BorderStyle.Fixed3D
        Panel3.Controls.Add(Button13)
        Panel3.Controls.Add(Button12)
        Panel3.Controls.Add(Button11)
        Panel3.Controls.Add(Button10)
        Panel3.Controls.Add(Button9)
        Panel3.Controls.Add(BtnC)
        Panel3.Controls.Add(Btn_dot)
        Panel3.Controls.Add(Btn0)
        Panel3.Controls.Add(Btn3)
        Panel3.Controls.Add(Btn2)
        Panel3.Controls.Add(Btn1)
        Panel3.Controls.Add(Btn6)
        Panel3.Controls.Add(Btn5)
        Panel3.Controls.Add(Btn4)
        Panel3.Controls.Add(Btn9)
        Panel3.Controls.Add(Btn8)
        Panel3.Controls.Add(Btn7)
        Panel3.Location = New Point(833, 15)
        Panel3.Margin = New Padding(3, 2, 3, 2)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(217, 248)
        Panel3.TabIndex = 31
        ' 
        ' Button13
        ' 
        Button13.BackColor = Color.Snow
        Button13.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Button13.Location = New Point(160, 198)
        Button13.Margin = New Padding(3, 2, 3, 2)
        Button13.Name = "Button13"
        Button13.Size = New Size(47, 44)
        Button13.TabIndex = 16
        Button13.Text = "="
        Button13.UseVisualStyleBackColor = False
        ' 
        ' Button12
        ' 
        Button12.BackColor = Color.Snow
        Button12.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Button12.Location = New Point(160, 152)
        Button12.Margin = New Padding(3, 2, 3, 2)
        Button12.Name = "Button12"
        Button12.Size = New Size(47, 44)
        Button12.TabIndex = 15
        Button12.Text = "+"
        Button12.UseVisualStyleBackColor = False
        ' 
        ' Button11
        ' 
        Button11.BackColor = Color.Snow
        Button11.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Button11.Location = New Point(160, 100)
        Button11.Margin = New Padding(3, 2, 3, 2)
        Button11.Name = "Button11"
        Button11.Size = New Size(47, 44)
        Button11.TabIndex = 14
        Button11.Text = "-"
        Button11.UseVisualStyleBackColor = False
        ' 
        ' Button10
        ' 
        Button10.BackColor = Color.Snow
        Button10.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Button10.Location = New Point(160, 2)
        Button10.Margin = New Padding(3, 2, 3, 2)
        Button10.Name = "Button10"
        Button10.Size = New Size(47, 44)
        Button10.TabIndex = 13
        Button10.Text = "/"
        Button10.UseVisualStyleBackColor = False
        ' 
        ' Button9
        ' 
        Button9.BackColor = Color.Snow
        Button9.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Button9.Location = New Point(160, 52)
        Button9.Margin = New Padding(3, 2, 3, 2)
        Button9.Name = "Button9"
        Button9.Size = New Size(47, 44)
        Button9.TabIndex = 12
        Button9.Text = "X"
        Button9.UseVisualStyleBackColor = False
        ' 
        ' BtnC
        ' 
        BtnC.BackColor = Color.Snow
        BtnC.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        BtnC.Location = New Point(108, 149)
        BtnC.Margin = New Padding(3, 2, 3, 2)
        BtnC.Name = "BtnC"
        BtnC.Size = New Size(47, 45)
        BtnC.TabIndex = 11
        BtnC.Text = "C"
        BtnC.UseVisualStyleBackColor = False
        ' 
        ' Btn_dot
        ' 
        Btn_dot.BackColor = Color.Snow
        Btn_dot.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Btn_dot.Location = New Point(55, 151)
        Btn_dot.Margin = New Padding(3, 2, 3, 2)
        Btn_dot.Name = "Btn_dot"
        Btn_dot.Size = New Size(47, 44)
        Btn_dot.TabIndex = 10
        Btn_dot.Text = "."
        Btn_dot.UseVisualStyleBackColor = False
        ' 
        ' Btn0
        ' 
        Btn0.BackColor = Color.Snow
        Btn0.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Btn0.Location = New Point(3, 149)
        Btn0.Margin = New Padding(3, 2, 3, 2)
        Btn0.Name = "Btn0"
        Btn0.Size = New Size(47, 45)
        Btn0.TabIndex = 9
        Btn0.Text = "0"
        Btn0.UseVisualStyleBackColor = False
        ' 
        ' Btn3
        ' 
        Btn3.BackColor = Color.Snow
        Btn3.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Btn3.Location = New Point(108, 100)
        Btn3.Margin = New Padding(3, 2, 3, 2)
        Btn3.Name = "Btn3"
        Btn3.Size = New Size(47, 44)
        Btn3.TabIndex = 8
        Btn3.Text = "3"
        Btn3.UseVisualStyleBackColor = False
        ' 
        ' Btn2
        ' 
        Btn2.BackColor = Color.Snow
        Btn2.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Btn2.Location = New Point(55, 102)
        Btn2.Margin = New Padding(3, 2, 3, 2)
        Btn2.Name = "Btn2"
        Btn2.Size = New Size(47, 44)
        Btn2.TabIndex = 7
        Btn2.Text = "2"
        Btn2.UseVisualStyleBackColor = False
        ' 
        ' Btn1
        ' 
        Btn1.BackColor = Color.Snow
        Btn1.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Btn1.Location = New Point(3, 100)
        Btn1.Margin = New Padding(3, 2, 3, 2)
        Btn1.Name = "Btn1"
        Btn1.Size = New Size(47, 44)
        Btn1.TabIndex = 6
        Btn1.Text = "1"
        Btn1.UseVisualStyleBackColor = False
        ' 
        ' Btn6
        ' 
        Btn6.BackColor = Color.Snow
        Btn6.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Btn6.Location = New Point(108, 52)
        Btn6.Margin = New Padding(3, 2, 3, 2)
        Btn6.Name = "Btn6"
        Btn6.Size = New Size(47, 44)
        Btn6.TabIndex = 5
        Btn6.Text = "6"
        Btn6.UseVisualStyleBackColor = False
        ' 
        ' Btn5
        ' 
        Btn5.BackColor = Color.Snow
        Btn5.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Btn5.Location = New Point(55, 53)
        Btn5.Margin = New Padding(3, 2, 3, 2)
        Btn5.Name = "Btn5"
        Btn5.Size = New Size(47, 44)
        Btn5.TabIndex = 4
        Btn5.Text = "5"
        Btn5.UseVisualStyleBackColor = False
        ' 
        ' Btn4
        ' 
        Btn4.BackColor = Color.Snow
        Btn4.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Btn4.Location = New Point(3, 52)
        Btn4.Margin = New Padding(3, 2, 3, 2)
        Btn4.Name = "Btn4"
        Btn4.Size = New Size(47, 44)
        Btn4.TabIndex = 3
        Btn4.Text = "4"
        Btn4.UseVisualStyleBackColor = False
        ' 
        ' Btn9
        ' 
        Btn9.BackColor = Color.Snow
        Btn9.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Btn9.Location = New Point(108, 1)
        Btn9.Margin = New Padding(3, 2, 3, 2)
        Btn9.Name = "Btn9"
        Btn9.Size = New Size(47, 44)
        Btn9.TabIndex = 2
        Btn9.Text = "9"
        Btn9.UseVisualStyleBackColor = False
        ' 
        ' Btn8
        ' 
        Btn8.BackColor = Color.Snow
        Btn8.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Btn8.Location = New Point(55, 1)
        Btn8.Margin = New Padding(3, 2, 3, 2)
        Btn8.Name = "Btn8"
        Btn8.Size = New Size(47, 44)
        Btn8.TabIndex = 1
        Btn8.Text = "8"
        Btn8.UseVisualStyleBackColor = False
        ' 
        ' Btn7
        ' 
        Btn7.BackColor = Color.Snow
        Btn7.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Btn7.Location = New Point(3, 1)
        Btn7.Margin = New Padding(3, 2, 3, 2)
        Btn7.Name = "Btn7"
        Btn7.Size = New Size(47, 44)
        Btn7.TabIndex = 0
        Btn7.Text = "7"
        Btn7.UseVisualStyleBackColor = False
        ' 
        ' Panel9
        ' 
        Panel9.BackColor = SystemColors.Control
        Panel9.BorderStyle = BorderStyle.Fixed3D
        Panel9.Controls.Add(BtnRemover)
        Panel9.Controls.Add(BtnPagamento)
        Panel9.Controls.Add(BtnLimpar)
        Panel9.Controls.Add(Btn_Imprimir)
        Panel9.Location = New Point(1089, 60)
        Panel9.Margin = New Padding(3, 2, 3, 2)
        Panel9.Name = "Panel9"
        Panel9.Size = New Size(168, 179)
        Panel9.TabIndex = 51
        ' 
        ' BtnRemover
        ' 
        BtnRemover.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        BtnRemover.Location = New Point(10, 42)
        BtnRemover.Margin = New Padding(3, 2, 3, 2)
        BtnRemover.Name = "BtnRemover"
        BtnRemover.Size = New Size(110, 30)
        BtnRemover.TabIndex = 38
        BtnRemover.Text = "Remover"
        BtnRemover.UseVisualStyleBackColor = True
        ' 
        ' BtnPagamento
        ' 
        BtnPagamento.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        BtnPagamento.Location = New Point(10, 7)
        BtnPagamento.Margin = New Padding(3, 2, 3, 2)
        BtnPagamento.Name = "BtnPagamento"
        BtnPagamento.Size = New Size(135, 31)
        BtnPagamento.TabIndex = 35
        BtnPagamento.Text = "Pagamento"
        BtnPagamento.UseVisualStyleBackColor = True
        ' 
        ' BtnLimpar
        ' 
        BtnLimpar.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        BtnLimpar.Location = New Point(10, 112)
        BtnLimpar.Margin = New Padding(3, 2, 3, 2)
        BtnLimpar.Name = "BtnLimpar"
        BtnLimpar.Size = New Size(91, 31)
        BtnLimpar.TabIndex = 36
        BtnLimpar.Text = "Limpar"
        BtnLimpar.UseVisualStyleBackColor = True
        ' 
        ' Btn_Imprimir
        ' 
        Btn_Imprimir.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Btn_Imprimir.Location = New Point(10, 75)
        Btn_Imprimir.Margin = New Padding(3, 2, 3, 2)
        Btn_Imprimir.Name = "Btn_Imprimir"
        Btn_Imprimir.Size = New Size(100, 32)
        Btn_Imprimir.TabIndex = 37
        Btn_Imprimir.Text = "Imprimir"
        Btn_Imprimir.UseVisualStyleBackColor = True
        ' 
        ' Panel7
        ' 
        Panel7.BackColor = SystemColors.Control
        Panel7.BorderStyle = BorderStyle.Fixed3D
        Panel7.Controls.Add(TextBoxTotal)
        Panel7.Controls.Add(cboPag)
        Panel7.Controls.Add(TextBoxIva)
        Panel7.Controls.Add(TextBoxSubTotal)
        Panel7.Controls.Add(lblTotal)
        Panel7.Controls.Add(TextBoxTroco)
        Panel7.Controls.Add(lblIva)
        Panel7.Controls.Add(lblSubTotal)
        Panel7.Controls.Add(lblTroco)
        Panel7.Controls.Add(lblFormaPag)
        Panel7.Controls.Add(TextBoxCusto)
        Panel7.Controls.Add(lblCusto)
        Panel7.Location = New Point(699, 60)
        Panel7.Margin = New Padding(3, 2, 3, 2)
        Panel7.Name = "Panel7"
        Panel7.Size = New Size(377, 258)
        Panel7.TabIndex = 50
        ' 
        ' TextBoxTotal
        ' 
        TextBoxTotal.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        TextBoxTotal.Location = New Point(139, 92)
        TextBoxTotal.Margin = New Padding(3, 2, 3, 2)
        TextBoxTotal.Name = "TextBoxTotal"
        TextBoxTotal.Size = New Size(222, 30)
        TextBoxTotal.TabIndex = 5
        ' 
        ' cboPag
        ' 
        cboPag.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        cboPag.FormattingEnabled = True
        cboPag.Location = New Point(138, 131)
        cboPag.Margin = New Padding(3, 2, 3, 2)
        cboPag.Name = "cboPag"
        cboPag.Size = New Size(223, 30)
        cboPag.TabIndex = 8
        ' 
        ' TextBoxIva
        ' 
        TextBoxIva.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        TextBoxIva.Location = New Point(139, 50)
        TextBoxIva.Margin = New Padding(3, 2, 3, 2)
        TextBoxIva.Name = "TextBoxIva"
        TextBoxIva.Size = New Size(222, 30)
        TextBoxIva.TabIndex = 4
        ' 
        ' TextBoxSubTotal
        ' 
        TextBoxSubTotal.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        TextBoxSubTotal.Location = New Point(139, 8)
        TextBoxSubTotal.Margin = New Padding(3, 2, 3, 2)
        TextBoxSubTotal.Name = "TextBoxSubTotal"
        TextBoxSubTotal.Size = New Size(222, 30)
        TextBoxSubTotal.TabIndex = 3
        ' 
        ' lblTotal
        ' 
        lblTotal.AutoSize = True
        lblTotal.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        lblTotal.Location = New Point(60, 94)
        lblTotal.Name = "lblTotal"
        lblTotal.Size = New Size(59, 23)
        lblTotal.TabIndex = 2
        lblTotal.Text = "Total:"
        ' 
        ' TextBoxTroco
        ' 
        TextBoxTroco.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        TextBoxTroco.Location = New Point(138, 218)
        TextBoxTroco.Margin = New Padding(3, 2, 3, 2)
        TextBoxTroco.Name = "TextBoxTroco"
        TextBoxTroco.Size = New Size(223, 30)
        TextBoxTroco.TabIndex = 7
        ' 
        ' lblIva
        ' 
        lblIva.AutoSize = True
        lblIva.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        lblIva.Location = New Point(75, 56)
        lblIva.Name = "lblIva"
        lblIva.Size = New Size(47, 23)
        lblIva.TabIndex = 1
        lblIva.Text = "IVA:"
        ' 
        ' lblSubTotal
        ' 
        lblSubTotal.AutoSize = True
        lblSubTotal.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        lblSubTotal.Location = New Point(17, 11)
        lblSubTotal.Name = "lblSubTotal"
        lblSubTotal.Size = New Size(93, 23)
        lblSubTotal.TabIndex = 0
        lblSubTotal.Text = "SubTotal:"
        ' 
        ' lblTroco
        ' 
        lblTroco.AutoSize = True
        lblTroco.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        lblTroco.Location = New Point(62, 223)
        lblTroco.Name = "lblTroco"
        lblTroco.Size = New Size(65, 23)
        lblTroco.TabIndex = 5
        lblTroco.Text = "Troco:"
        ' 
        ' lblFormaPag
        ' 
        lblFormaPag.AutoSize = True
        lblFormaPag.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        lblFormaPag.Location = New Point(3, 133)
        lblFormaPag.Name = "lblFormaPag"
        lblFormaPag.Size = New Size(115, 23)
        lblFormaPag.TabIndex = 3
        lblFormaPag.Text = "Forma Pag:"
        ' 
        ' lblCusto
        ' 
        lblCusto.AutoSize = True
        lblCusto.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        lblCusto.Location = New Point(60, 181)
        lblCusto.Name = "lblCusto"
        lblCusto.Size = New Size(67, 23)
        lblCusto.TabIndex = 4
        lblCusto.Text = "Custo:"
        ' 
        ' DataGridView1
        ' 
        DataGridView1.BackgroundColor = Color.Snow
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Columns.AddRange(New DataGridViewColumn() {Column1, Column2, Column3})
        DataGridView1.Location = New Point(241, 60)
        DataGridView1.Margin = New Padding(3, 2, 3, 2)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowHeadersWidth = 51
        DataGridView1.RowTemplate.Height = 29
        DataGridView1.Size = New Size(428, 257)
        DataGridView1.TabIndex = 52
        ' 
        ' Column1
        ' 
        Column1.HeaderText = "Item"
        Column1.MinimumWidth = 6
        Column1.Name = "Column1"
        Column1.Width = 125
        ' 
        ' Column2
        ' 
        Column2.HeaderText = "Qtd"
        Column2.MinimumWidth = 6
        Column2.Name = "Column2"
        Column2.Width = 125
        ' 
        ' Column3
        ' 
        Column3.HeaderText = "Valor"
        Column3.MinimumWidth = 6
        Column3.Name = "Column3"
        Column3.Width = 125
        ' 
        ' TextBoxCusto
        ' 
        TextBoxCusto.Font = New Font("Century Gothic", 13.8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        TextBoxCusto.Location = New Point(138, 176)
        TextBoxCusto.Margin = New Padding(3, 2, 3, 2)
        TextBoxCusto.Name = "TextBoxCusto"
        TextBoxCusto.Size = New Size(223, 30)
        TextBoxCusto.TabIndex = 6
        ' 
        ' PagamentoForm
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1312, 600)
        Controls.Add(Panel6)
        Controls.Add(Panel9)
        Controls.Add(Panel7)
        Controls.Add(DataGridView1)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Margin = New Padding(3, 2, 3, 2)
        Name = "PagamentoForm"
        StartPosition = FormStartPosition.CenterScreen
        Text = "PagamentoForm"
        Panel2.ResumeLayout(False)
        GroupBoxPesquisa.ResumeLayout(False)
        GroupBoxPesquisa.PerformLayout()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        Panel6.ResumeLayout(False)
        CType(DataGridView2, ComponentModel.ISupportInitialize).EndInit()
        Panel4.ResumeLayout(False)
        Panel3.ResumeLayout(False)
        Panel9.ResumeLayout(False)
        Panel7.ResumeLayout(False)
        Panel7.PerformLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel2 As Panel
    Friend WithEvents GroupBoxPesquisa As GroupBox
    Friend WithEvents lblPesquisar As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents BtnFechar As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Lbl_time As Label
    Friend WithEvents Lbl_Data As Label
    Friend WithEvents Lbl_User As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Button7 As Button
    Friend WithEvents BtnMesa1 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents BtnMesa11 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents BtnMesa7 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents BtnMesa12 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents BtnMesa6 As Button
    Friend WithEvents BtnMesa5 As Button
    Friend WithEvents BtnMesa16 As Button
    Friend WithEvents BtnMesa15 As Button
    Friend WithEvents BtnMesa2 As Button
    Friend WithEvents BtnMesa10 As Button
    Friend WithEvents BtnMesa20 As Button
    Friend WithEvents BtnMesa19 As Button
    Friend WithEvents BtnMesa17 As Button
    Friend WithEvents BtnMesa4 As Button
    Friend WithEvents BtnMesa13 As Button
    Friend WithEvents BtnMesa3 As Button
    Friend WithEvents BtnMesa9 As Button
    Friend WithEvents BtnMesa18 As Button
    Friend WithEvents BtnMesa14 As Button
    Friend WithEvents BtnMesa8 As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents BtnC As Button
    Friend WithEvents Btn_dot As Button
    Friend WithEvents Btn0 As Button
    Friend WithEvents Btn3 As Button
    Friend WithEvents Btn2 As Button
    Friend WithEvents Btn1 As Button
    Friend WithEvents Btn6 As Button
    Friend WithEvents Btn5 As Button
    Friend WithEvents Btn4 As Button
    Friend WithEvents Btn9 As Button
    Friend WithEvents Btn8 As Button
    Friend WithEvents Btn7 As Button
    Friend WithEvents Panel9 As Panel
    Friend WithEvents BtnRemover As Button
    Friend WithEvents BtnPagamento As Button
    Friend WithEvents BtnLimpar As Button
    Friend WithEvents Btn_Imprimir As Button
    Friend WithEvents Panel7 As Panel
    Friend WithEvents TextBoxTotal As TextBox
    Friend WithEvents cboPag As ComboBox
    Friend WithEvents TextBoxIva As TextBox
    Friend WithEvents TextBoxSubTotal As TextBox
    Friend WithEvents lblTotal As Label
    Friend WithEvents TextBoxTroco As TextBox
    Friend WithEvents lblIva As Label
    Friend WithEvents lblSubTotal As Label
    Friend WithEvents lblTroco As Label
    Friend WithEvents lblFormaPag As Label
    Friend WithEvents lblCusto As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents BtnRecuperarSenha As Button
    Friend WithEvents BtnUsuarios As Button
    Friend WithEvents BtnAbout As Button
    Friend WithEvents BtnMesas As Button
    Friend WithEvents BtnProdutoBruto As Button
    Friend WithEvents BtnFornecedor As Button
    Friend WithEvents BtnPratos As Button
    Friend WithEvents BtnStock As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents BtnPedidosDelivery As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents BtnLogout As Button
    Friend WithEvents TextBoxCusto As TextBox
End Class
