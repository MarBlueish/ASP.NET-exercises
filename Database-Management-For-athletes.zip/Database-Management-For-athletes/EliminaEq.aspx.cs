﻿using System;
using System.Data.SqlClient;
using System.Web.UI;

namespace Ati7FPFutebol
{
    public partial class EliminaEq : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            Lista_equipas();

        }

        protected void Lista_equipas()
        {
            string connetionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Ati7FPFutebol\App_Data\dbFPF.mdf;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connetionString))
            {
                con.Open();

                SqlCommand command;
                SqlDataReader dataReader;
                String sql;
                sql = "SELECT * FROM tab_equipa";

                command = new SqlCommand(sql, con);
                dataReader = command.ExecuteReader();

                string output = "<table border='1'>";

                output += "<tr><th>Sigla</th><th>Descrição</th><th>Logo</th><th>Eliminar</th></tr>";

                while (dataReader.Read())
                {
                    output += "<tr>" +
                              $"<td>{dataReader["sigla"]}</td>" +
                              $"<td>{dataReader["descricao"]}</td>" +
                              $"<td>{dataReader["logo"]}</td>" +
                              $"<td><a href='EliminaEq.aspx?sigla={dataReader["sigla"]}'>Eliminar</a></td>" +
                              "</tr>";
                }

                output += "</table>";

                ltOutput.Text = output;
            }
        }

        protected void EliminarEquipa(string sigla)
        {
            string connetionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Ati7FPFutebol\App_Data\dbFPF.mdf;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connetionString))
            {
                con.Open();

                string checkSql = "SELECT COUNT(*) FROM tab_jogador WHERE Equipa_Sigla = @Sigla";

                using (SqlCommand checkCommand = new SqlCommand(checkSql, con))
                {
                    checkCommand.Parameters.AddWithValue("@Sigla", sigla);
                    int jogadorCount = (int)checkCommand.ExecuteScalar();

                    if (jogadorCount > 0)
                    {
                        ltOutput.Text = "Não podes eliminar a equipa enquanto houver jogadores associados.";
                        return;
                    }
                }

                string deleteSql = "DELETE FROM tab_equipa WHERE sigla = @Sigla";

                using (SqlCommand deleteCommand = new SqlCommand(deleteSql, con))
                {
                    deleteCommand.Parameters.AddWithValue("@Sigla", sigla);
                    int rowsAffected = deleteCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        ltOutput.Text = "Equipa eliminada com sucesso";
                    }
                    else
                    {
                        ltOutput.Text = "Erro ao eliminar a equipa";
                    }
                }
            }

            Lista_equipas();

        }
    }
}