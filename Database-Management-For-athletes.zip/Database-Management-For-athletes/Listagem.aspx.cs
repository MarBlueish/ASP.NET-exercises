﻿using System;
using System.Data.SqlClient;
using System.Web.UI;

namespace Ati7FPFutebol
{
    public partial class Listagem : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Lista_dados();
        }

        protected void Lista_dados()
        {
            string connetionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Ati7FPFutebol\App_Data\dbFPF.mdf;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connetionString))
            {
                con.Open();

                SqlCommand command;
                SqlDataReader dataReader;
                String sql;
                sql = "SELECT * FROM tab_jogador";

                command = new SqlCommand(sql, con);
                dataReader = command.ExecuteReader();

                string output = "<table border='1'>";

                output += "<tr><th>ID</th><th>Nome</th><th>Email</th><th>Data de Nascimento</th><th>Morada</th><th>Equipa Sigla</th><th>Posição ID</th></tr>";

                while (dataReader.Read())
                {
                    output += "<tr>" +
                              $"<td>{dataReader["N_federacao"]}</td>" +
                              $"<td>{dataReader["Nome"]}</td>" +
                              $"<td>{dataReader["Email"]}</td>" +
                              $"<td>{dataReader["Data_Nasc"]}</td>" +
                              $"<td>{dataReader["Morada"]}</td>" +
                              $"<td>{dataReader["Equipa_Sigla"]}</td>" +
                              $"<td>{dataReader["posicao_id"]}</td>" +
                              "</tr>";
                }

                output += "</table>";

                ltOutput.Text = output;
            }
        }
    }
}



